# PrimeDirective
Project in java that finds Prime no in Array and ArrayList!
This is a codecademy project in java!
Link:https://www.codecademy.com/courses/learn-java/projects/java-prime-directive

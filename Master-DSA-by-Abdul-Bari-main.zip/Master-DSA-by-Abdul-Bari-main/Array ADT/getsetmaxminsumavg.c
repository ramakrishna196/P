#include <stdio.h>
#include <stdlib.h>

struct Array
{
    int A[10];
    int size;
    int length;
};

int Get(struct Array arr, int index)
{
    if (index >= 0 && index < arr.length)
    {
        return arr.A[index];
    }
}

int Set(struct Array *arr, int index, int x)
{
    if (index >= 0 && index < arr->length)
    {
        arr->A[index] = x;
    }
    return arr->A[index];
}

int Max(struct Array arr)
{
    int max = arr.A[0];
    for (int i = 0; i < arr.length; i++)
    {
        if (arr.A[i] > max)
        {
            max = arr.A[i];
        }
    }
    return max;
}

int Min(struct Array arr)
{
    int min = arr.A[0];
    for (int i = 0; i < arr.length; i++)
    {
        if (arr.A[i] < min)
        {
            min = arr.A[i];
        }
    }
    return min;
}

int Sum(struct Array arr)
{
    int total = arr.A[0];
    for (int i = 0; i < arr.length; i++)
    {
        total += arr.A[i];
    }
    return total;
}

float Avg(struct Array arr)
{
    return (float)Sum(arr) / arr.length;
}

int main()
{
    // for static memory allocation of array in STACK
    struct Array arr = {{2, 4, 6, 8, 10, 12, 14, 16, 18, 20}, 10, 10};
    // printf("%d\n", Set(&arr, 5, 1));
    // printf("%d\n", Get(arr, 5));
    printf("Max: %d\n", Max(arr));
    printf("Min: %d\n", Min(arr));
    printf("Sum: %d\n", Sum(arr));
    printf("Avg: %f\n", Avg(arr));
    return 0;
}
#include <stdio.h>
#include <stdlib.h>

struct Array
{
    int A[10];
    int size;
    int length;
};

void Display(struct Array arr)
{
    printf("Elements are: \n");
    for (int i = 0; i < arr.length; i++)
    {
        printf("%d ", arr.A[i]);
    }
}

void Append(struct Array *arr, int x)
{
    if (arr->length < arr->size)
    {
        arr->A[arr->length] = x;
    }
    arr->length++;
}

int main()
{
    // for static memory allocation of array in STACK
    struct Array arr = {{1, 2, 3, 4, 5}, 10, 5};
    Append(&arr, 10);
    Display(arr);
    return 0;
}
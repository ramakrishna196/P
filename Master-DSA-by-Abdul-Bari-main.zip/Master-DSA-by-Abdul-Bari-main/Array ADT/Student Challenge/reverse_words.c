#include <stdlib.h>
#include <stdio.h>

struct CharArray
{
    char C[25];
    int size;
    int length;
};

void Display(struct CharArray arr)
{
    for (int i = 0; i < arr.length; i++)
    {
        printf("%c", arr.C[i]);
    }
}

void reverse(struct CharArray *arr, int start, int end)
{
    while (start < end)
    {
        int temp = arr->C[start];
        arr->C[start++] = arr->C[end];
        arr->C[end--] = temp;
    }
}

void reverse_words(struct CharArray *arr)
{
    int wstart = 0;
    for (int i = 0; i < arr->length; i++)
    {
        if (arr->C[i] == ' ')
        {
            reverse(arr, wstart, i - 1);
            wstart = i + 1;
        }
    }
    reverse(arr, wstart, arr->length - 1);
}

void main()
{
    struct CharArray arr = {"Programming is an art", 25, 22};
    reverse_words(&arr);
    Display(arr);
}

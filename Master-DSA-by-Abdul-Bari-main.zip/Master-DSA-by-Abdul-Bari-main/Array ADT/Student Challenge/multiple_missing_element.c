#include <stdio.h>
#include <stdlib.h>

struct Array
{
    int A[10];
    int size;
    int length;
};

void MissingElement(struct Array arr)
{
    int l, n, diff;
    l = arr.A[0];
    n = arr.length;
    diff = l - 0;
    printf("Missing Element: ");
    for (int i = 0; i < n; i++)
    {
        if (arr.A[i] - i != diff)
        {
            while (diff < arr.A[i] - i)
            {
                printf("%d ", diff + i);
                diff++;
            }
        }
    }
}

void main()
{
    // for static memory allocation of array in STACK
    struct Array arr = {{6, 8, 9, 10, 13, 14, 15, 16, 18}, 10, 9};
    MissingElement(arr);
}
#include <stdio.h>
#include <stdlib.h>

struct Array
{
  int A[10];
  int size;
  int length;
};

void FindSingleMissingElementInSortedArray(struct Array arr)
{
  int sum, n;
  sum = 0, n = arr.A[arr.length - 1];
  for (int i = 0; i < arr.length; i++)
  {
    sum += arr.A[i];
  }
  int diff = n * (n + 1) / 2 - sum;
  if (sum != n * (n + 1) / 2)
  {
    printf("Missing Element is: %d\n", diff);
  }
}

void FindSingleMissingElementInUnSortedArray(struct Array arr)
{
  int l, h, n, diff;
  l = arr.A[0];
  h = arr.A[arr.length - 1];
  n = arr.length;
  diff = l - 0;
  for (int i = 0; i < n; i++)
  {
    if (arr.A[i] - i != diff)
    {
      printf("Missing Element is: %d\n", diff + i);
      break;
    }
  }
}

void main()
{
  // for static memory allocation of array in STACK
  struct Array arr = {{1, 2, 3, 4, 5, 6, 8, 9, 10}, 10, 9};
  struct Array arree = {{6, 7, 8, 9, 10, 11, 13, 14, 15, 16}, 10, 9};
  FindSingleMissingElementInSortedArray(arr);
  FindSingleMissingElementInUnSortedArray(arree);
}
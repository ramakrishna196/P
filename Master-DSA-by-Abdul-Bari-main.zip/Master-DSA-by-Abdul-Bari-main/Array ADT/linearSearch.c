#include <stdio.h>
#include <stdlib.h>

struct Array
{
    int A[10];
    int size;
    int length;
};

void Swap(int *x, int *y)
{
    int temp = *x;
    *x = *y;
    *y = temp;
}

int LinearSearch(struct Array arr, int key)
{
    for (int i = 0; i < arr.length; i++)
    {
        if (key == arr.A[i])
        {
            return i;
        }
    }
    return -1;
}

// On each Linear Search Swap element at one back index
int Transposition(struct Array *arr, int key)
{
    for (int i = 0; i < arr->length; i++)
    {
        if (key == arr->A[i])
        {
            Swap(&arr->A[i], &arr->A[i - 1]);
            return i;
        }
    }
    return -1;
}

// On each Linear Search Swap element to the front
int MoveToFront(struct Array *arr, int key)
{
    for (int i = 0; i < arr->length; i++)
    {
        if (key == arr->A[i])
        {
            Swap(&arr->A[i], &arr->A[0]);
            return i;
        }
    }
    return -1;
}

void Display(struct Array arr)
{
    printf("Elements are: ");
    for (int i = 0; i < arr.length; i++)
    {
        printf("%d ", arr.A[i]);
    }
    printf("\n");
}

int main()
{
    // for static memory allocation of array in STACK
    struct Array arr = {{11, 22, 33, 44, 55}, 10, 5};
    printf("Index of element 11 is (using Linear Search): %d\n", LinearSearch(arr, 11));
    Display(arr);
    printf("\nIndex of element 22 is (using Transposition Search): %d\n", Transposition(&arr, 22));
    Display(arr);
    printf("\nIndex of element 55 is (using Move to Head/First Search): %d\n", MoveToFront(&arr, 55));
    Display(arr);
    return 0;
}

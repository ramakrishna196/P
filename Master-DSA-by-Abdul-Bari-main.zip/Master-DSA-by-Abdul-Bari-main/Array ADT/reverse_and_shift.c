#include <stdio.h>
#include <stdlib.h>

struct Array
{
  int A[10];
  int size;
  int length;
};

void Display(struct Array arr)
{
  printf("\nElements are: \n");
  for (int i = 0; i < arr.length; i++)
  {
    printf("%d ", arr.A[i]);
  }
}

void ReverseUsingAuxilaryArray(struct Array *arr)
{
  int *B;
  B = (int *)malloc(arr->length * sizeof(int));
  for (int i = arr->length - 1, j = 0; i >= 0; i--, j++)
  {
    B[j] = arr->A[i];
  }
  for (int i = 0; i < arr->length; i++)
  {
    arr->A[i] = B[i];
  }
}

void Reverse(struct Array *arr)
{
  for (int i = 0, j = arr->length - 1; i < j; i++, j--)
  {
    int temp = arr->A[i];
    arr->A[i] = arr->A[j];
    arr->A[j] = temp;
  }
}

void LeftShift(struct Array *arr)
{
  for (int i = 1; i < arr->length; i++)
  {
    arr->A[i - 1] = arr->A[i];
  }
  arr->length--;
}

void LeftRotation(struct Array *arr)
{
  int temp = arr->A[0];
  LeftShift(arr);
  arr->A[arr->length] = temp;
  arr->length++;
}

void LeftRotationByNumber(struct Array *arr, int n)
{
  while (n > 0)
  {
    LeftRotation(arr);
    n--;
  }
}

void main()
{
  // for static memory allocation of array in STACK
  struct Array arr = {{8, 3, 9, 15, 6, 10, 7, 2, 12, 4}, 10, 10};
  // Reverse(&arr);
  // ReverseUsingAuxilaryArray(&arr);
  // LeftRotation(&arr);
  LeftRotationByNumber(&arr, 2);
  Display(arr);
}
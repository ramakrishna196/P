#include <stdio.h>
#include <stdlib.h>

/*
NOTE: To Performing Binary Search the Elements of the Array must be sorted!
Why it is called the binary search because it will always check for a key element in the middle of the
sorted list. & it will split the list into two.
*/

struct Array
{
    int A[10];
    int size;
    int length;
};

int IterativeBinarySearch(struct Array arr, int key)
{
    int l, h, mid;
    l = 0;
    h = arr.length - 1;
    while (l <= h)
    {
        mid = (l + h) / 2;
        if (key == arr.A[mid])
        {
            return mid;
        }
        else if (key < arr.A[mid])
        {
            h = mid - 1;
        }
        else
        {
            l = mid + 1;
        }
    }
    return -1;
}

int RecursiveBinarySearch(struct Array arr, int l, int h, int key)
{
    int mid;
    if (l <= h)
    {
        mid = (l + h) / 2;
        if (key == arr.A[mid])
        {
            return mid;
        }
        else if (key < arr.A[mid])
        {
            return RecursiveBinarySearch(arr, l, mid - 1, key);
        }
        else
        {
            return RecursiveBinarySearch(arr, mid + 1, h, key);
        }
    }
    return -1;
}

void Display(struct Array arr)
{
    printf("Elements are: ");
    for (int i = 0; i < arr.length; i++)
    {
        printf("%d ", arr.A[i]);
    }
    printf("\n");
}

int main()
{
    // for static memory allocation of array in STACK
    struct Array arr = {{10, 11, 22, 33, 44, 55, 66, 77, 88, 99}, 10, 10};
    Display(arr);
    printf("%d", IterativeBinarySearch(arr, 33));
    printf("%d", RecursiveBinarySearch(arr, 0, arr.length - 1, 55));
    return 0;
}

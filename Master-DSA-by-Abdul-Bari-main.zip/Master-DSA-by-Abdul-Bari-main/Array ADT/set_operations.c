#include <stdio.h>
#include <stdlib.h>

struct Array
{
    int A[10];
    int size;
    int length;
};

void Display(struct Array arr)
{
    printf("\nElements are: \n");
    for (int i = 0; i < arr.length; i++)
    {
        printf("%d ", arr.A[i]);
    }
}

struct Array *UnionOfUnsorted(struct Array arr1, struct Array arr2)
{
    struct Array *arr3 = (struct Array *)malloc(sizeof(struct Array));
    arr3->length = 0;
    int j = 0;
    for (int i = 0; i < arr1.length; i++)
    {
        arr3->A[i] = arr1.A[i];
        arr3->length++;
    }
    for (int k = 0; k < arr2.length; k++)
    {
        if (arr2.A[j] != arr3->A[k])
        {
            arr3->A[arr3->length] = arr2.A[j++];
            arr3->length++;
        }
        else
        {
            j++;
        }
    }
    arr3->size = 10;
    return arr3;
}

struct Array *UnionOfSorted(struct Array A, struct Array B)
{
    int i, j, k;
    i = j = k = 0;
    struct Array *C = (struct Array *)malloc(sizeof(struct Array));
    while (i < A.length && j < B.length)
    {
        if (A.A[i] < B.A[j])
        {
            C->A[k++] = A.A[i++];
        }
        else if (B.A[j] < A.A[i])
        {
            C->A[k++] = B.A[j++];
        }
        else
        {
            C->A[k++] = A.A[i++];
            j++;
        }
    }
    for (; i < A.length; i++)
    {
        C->A[k++] = A.A[i];
    }
    for (; j < A.length; j++)
    {
        C->A[k++] = B.A[j];
    }
    C->length = k;
    C->size = 10;
    return C;
}

struct Array *IntersectionOfUnsorted(struct Array arr1, struct Array arr2)
{
    int i, j, k;
    i = k = 0;
    struct Array *arr3 = (struct Array *)malloc(sizeof(struct Array));
    while (i < arr1.length)
    {
        j = 0;
        while (j < arr2.length)
        {
            if (arr1.A[i] == arr2.A[j])
            {
                arr3->A[k++] = arr2.A[j++];
            }
            else
            {
                j++;
            }
        }
        i++;
    }
    arr3->length = k;
    arr3->size = 10;
    return arr3;
}

struct Array *IntersectionOfSorted(struct Array A, struct Array B)
{
    int i, j, k;
    i = j = k = 0;
    struct Array *C = (struct Array *)malloc(sizeof(struct Array));

    while (i < A.length && j < B.length)
    {
        if (A.A[i] < B.A[j])
        {
            i++;
        }
        else if (B.A[j] < A.A[i])
        {
            j++;
        }
        else if (A.A[i] == B.A[j])
        {
            C->A[k++] = A.A[i++];
            j++;
        }
    }

    C->length = k;
    C->size = 10;
    return C;
}

struct Array *DifferenceOfUnsorted(struct Array arr1, struct Array arr2)
{
    int i, j, k, flag;
    i = k = 0;
    struct Array *arr3 = (struct Array *)malloc(sizeof(struct Array));
    while (i < arr1.length)
    {
        j = 0;
        flag = 1;
        while (j < arr2.length)
        {
            if (arr1.A[i] == arr2.A[j])
            {
                j++;
                flag = 0;
                continue;
            }
            j++;
        }
        if (flag == 1)
        {
            arr3->A[k++] = arr1.A[i];
        }
        i++;
    }

    arr3->length = k;
    arr3->size = 10;
    return arr3;
}

struct Array *DifferenceOfSorted(struct Array A, struct Array B)
{
    int i, j, k;
    i = j = k = 0;
    struct Array *C = (struct Array *)malloc(sizeof(struct Array));

    while (i < A.length && j < B.length)
    {
        if (A.A[i] < B.A[j])
        {
            C->A[k++] = A.A[i++];
        }
        else if (B.A[j] < A.A[i])
        {
            j++;
        }
        else if (A.A[i] == B.A[j])
        {
            i++;
            j++;
        }
    }

    C->length = k;
    C->size = 10;
    return C;
}

void main()
{
    // for static memory allocation of array in STACK
    // Unsorted Array
    struct Array arr1 = {{2, 7, 10, 4, 9}, 10, 5};
    struct Array arr2 = {{12, 5, 10, 3, 8}, 10, 5};
    struct Array *arr3;
    // Sorted Array
    struct Array A = {{2, 4, 7, 9, 10}, 10, 5};
    struct Array B = {{3, 5, 8, 10, 12}, 10, 5};
    struct Array *C;

    // arr3 = UnionOfUnsorted(arr1, arr2);
    // C = UnionOfSorted(A, B);
    // arr3 = IntersectionOfUnsorted(arr1, arr2);
    // C = IntersectionOfSorted(A, B);
    arr3 = DifferenceOfUnsorted(arr1, arr2);
    C = DifferenceOfSorted(A, B);
    Display(*arr3);
}
#include <stdlib.h>
#include <stdio.h>

// Stack follows LIFO (Last In First Out) Method.
// Ex. Browser Address History, a stack of dinner plates, etc.

struct Array
{
    int A[10];
    int size;
    int top;
};

void push(struct Array *arr, int val)
{
    if (arr->top == arr->size - 1)
    {
        printf("Stack is full\n");
    }
    else
    {
        arr->top++;
        arr->A[arr->top] = val;
        printf("Pushed the element!\n");
    }
}

void pop(struct Array *arr)
{
    if (arr->top == -1)
    {
        printf("Stack is empty\n");
    }
    else
    {
        printf("Popped element is: %d\n", arr->A[arr->top]);
        arr->top--;
    }
}

void main()
{
    struct Array arr = {{1, 2, 3}, 10, 2};
    pop(&arr);
}

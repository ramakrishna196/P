#include <stdlib.h>
#include <stdio.h>

// Stack follows LIFO (Last In First Out) Method.
// Ex. Browser Address History, a stack of dinner plates, etc.

struct Array
{
    int A[3];
    int size;
    int front;
    int rear;
};

void Enqueue(struct Array *arr, int val)
{
    if (arr->rear == arr->size)
    {
        printf("Queue is full, so element %d can't be added\n", val);
    }
    else
    {
        arr->A[arr->rear] = val;
        arr->rear++;
        printf("Added element %d to the Queue!\n", val);
    }
}

void Dequeue(struct Array *arr)
{
    if (arr->front == arr->rear)
    {
        printf("Queue is empty\n");
    }
    else
    {
        printf("Dequeued element = %d\n", arr->A[arr->front]);
        arr->front++;
    }
}

void main()
{
    struct Array arr = {{}, 3, 0, 0};
    Enqueue(&arr, 2);
    Dequeue(&arr);
}
